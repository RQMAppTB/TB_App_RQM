# Application mobile pour le projet de TB Application mobile "Objectif 2'000'000 m"

Cette application est prévue pour fonctionner de concert avec (ce serveur)[https://github.com/MasterZeus97/TB_Serveur].

Pour pouvoir compiler ce projet, il est nécessaire d'avoir [installé Flutter](https://docs.flutter.dev/get-started/install). Une fois que l'installation est terminée, utiliser la commande  
`flutter pub get`  
à l'intérieur du fichier tb_app_rqm afin d'installer les dépendances. Le projet peut maintenant être compilé.