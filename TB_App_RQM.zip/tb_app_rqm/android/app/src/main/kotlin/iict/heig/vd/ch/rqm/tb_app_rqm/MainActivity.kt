package iict.heig.vd.ch.rqm.tb_app_rqm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
